import os
from datetime import datetime

import download

if __name__ == '__main__':
    download.down_usgs_by_id('LC82270682017167LGN00','/Users/gustavojunior/Documents/','usgs.txt')
